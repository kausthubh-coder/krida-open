import { type BodyPreset, type BodyPresetName } from './presets';
/** What the shader needs from the body. */
export type BodyPose = {
    /** l=2 amplitude x (cos, sin) of twice its angle, then l=3 x thrice. */
    modes: [number, number, number, number];
    squash: [number, number];
    swell: number;
    /** Extra rim light from contact, 0 to 1. */
    glow: number;
    width: number;
    height: number;
    tilt: [number, number];
};
export type BodySnapshot = {
    modes: {
        value: number;
        velocity: number;
    }[];
    squash: {
        value: number;
        velocity: number;
    };
    tilt: [number, number];
};
export declare class BubbleBody {
    preset: BodyPreset;
    /** Scales every kick and press; 0 means nothing jiggles. */
    wobble: number;
    /** Reduced motion: every change lands at once. */
    still: boolean;
    private readonly m2a;
    private readonly m2b;
    private readonly m3a;
    private readonly m3b;
    private readonly squash;
    private readonly stretch;
    private stretchAngle;
    private stretchHold;
    private readonly swell;
    private readonly glow;
    private typeSign;
    private readonly width;
    private readonly height;
    private readonly tiltX;
    private readonly tiltY;
    private pressed;
    /** Swell the component asked for, under the press. */
    private restSwell;
    private accumulator;
    private shapeAwake;
    private tiltAwake;
    constructor(preset?: BodyPresetName | BodyPreset, wobble?: number);
    private get kickScale();
    /** Rings the shape modes along a direction, as a push from that side. */
    kick(strength: number, angle: number): void;
    /** The pointer came in from (x, y), in radii from the centre, y up. */
    enter(x: number, y: number): void;
    leave(x: number, y: number): void;
    /** Reflections follow the pointer. Costs no outline redraw and no wobble. */
    pointTo(x: number, y: number): void;
    press(): void;
    release(): void;
    /** A component's own swell, as a slider thumb's while dragged. */
    setSwell(scale: number): void;
    private applySwell;
    /** The bubble is being carried at this velocity, in radii per second: it stretches along it. */
    moveWith(vx: number, vy: number): void;
    /** The box changed size. It springs to it and rings, subtly, along the axis that changed. */
    resizeTo(width: number, height: number, radius?: number): void;
    /** Keeps the current size inside the given box, for a canvas that just shrank. */
    limitSize(width: number, height: number): void;
    /** Lost the one hover: everything hurries home with no ring. */
    settleFast(): void;
    /**
     * A key went in: a small wobble, as a little press would give, each one the other
     * way so that typing keeps it moving without building up.
     */
    typed(deleting?: boolean): void;
    /** The rim brightens for contact, 0 to 1. Costs a few draws, not a resize. */
    setGlow(value: number): void;
    /** One reflection runs across the rim from a corner and settles: a panel's arrival. */
    sweep(): void;
    /** An opening menu's rebound: excites the same modes as the pointer. */
    rebound(): void;
    private shapeSprings;
    /** The outline is moving and needs drawing every frame. */
    get shapeMoving(): boolean;
    /** Only the reflections are moving, which a film-rate draw covers. */
    get tiltMoving(): boolean;
    get asleep(): boolean;
    /** Simulates this much time, in fixed steps. Longer gaps are cut off rather than fast-forwarded. */
    advance(seconds: number): void;
    private step;
    private updateSleep;
    pose(): BodyPose;
    /** The wobble and tilt, for another bubble to carry on (a menu panel for its trigger). */
    snapshot(): BodySnapshot;
    adopt(snapshot: BodySnapshot): void;
}
