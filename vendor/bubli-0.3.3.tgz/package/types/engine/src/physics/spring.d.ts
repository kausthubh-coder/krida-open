export type SpringConfig = {
    stiffness: number;
    damping: number;
};
export declare function fromFrequency(hz: number, zeta: number): SpringConfig;
/** Damping ratio of a stiffness/damping pair: below 1 overshoots. */
export declare const dampingRatio: ({ stiffness, damping }: SpringConfig) => number;
/** Fraction a step response overshoots its target. */
export declare function overshootOf(config: SpringConfig): number;
export declare class Spring {
    value: number;
    velocity: number;
    target: number;
    config: SpringConfig;
    /** Below these the spring counts as asleep and snaps to its target. */
    readonly epsilon: number;
    constructor(value: number, config: SpringConfig, epsilon?: number);
    /** Semi-implicit Euler: stable at the body's 240 Hz step. */
    step(dt: number): void;
    asleep(): boolean;
    /** Snap to the target if asleep; returns whether it was. */
    settle(): boolean;
    snap(value?: number): void;
}
export declare const FIXED_STEP: number;
/** Longest stretch of time one advance will simulate; a hidden tab doesn't fast-forward. */
export declare const MAX_ADVANCE = 0.05;
