import type { Bend } from '../capability/mode';
export declare const SCENE_ID = "bubli-scene";
/** Bevel and strength for a control this size: tied to its short side, capped so big things stay calm. */
export declare function bendSizes(width: number, height: number, maxStrength?: number): {
    bevel: number;
    strength: number;
    pad: number;
};
export type BendLayer = {
    /** The bubble's box changed: new map for the new size. */
    layout: (width: number, height: number, radius: number) => void;
    /** Keeps the bend to this part of the box, as a panel grows. Null is all of it. */
    shape: (rect: {
        x: number;
        y: number;
        width: number;
        height: number;
    } | null, radius?: number) => void;
    /** Keeps -moz-element in register with the page. */
    position: () => void;
    /** Follows a swell without touching the map. */
    scale: (value: number) => void;
    setLive: (live: boolean) => void;
    /** Whether this bubble could bend live at all: outside the scene, in Firefox. Only those compete for slots. */
    canBendLive: () => boolean;
    dispose: () => void;
};
/** The layer is the padded element; its parent is the clip the shape of the glass. */
export type BendVariant = 'regular' | 'clear' | 'bar';
export declare function createBendLayer(layer: HTMLElement, kind: Bend, maxStrength?: number, variant?: BendVariant, sceneId?: string): BendLayer;
