export type Glass = 'bubble' | 'plain';
export type Bend = 'svg' | 'moz' | 'blur' | 'none';
export type Motion = 'full' | 'reduced';
export type GlassPreference = 'auto' | 'bubble' | 'plain';
export type BendPreference = 'auto' | 'off';
export type Mode = {
    glass: Glass;
    bend: Bend;
    motion: Motion;
    reason: string | null;
};
/** What the environment says, read once and on change. Pure input to decideMode, so it can be tested. */
export type Environment = {
    reducedTransparency: boolean;
    reducedMotion: boolean;
    moreContrast?: boolean;
    /** navigator.deviceMemory in GB, when the browser tells. */
    deviceMemory?: number;
    saveData: boolean;
    bendSupport: Bend;
};
export type Preferences = {
    glass: GlassPreference;
    bend: BendPreference;
};
export declare function decideMode(env: Environment, prefs: Preferences, failures: ReadonlySet<string>): Mode;
/**
 * Which live bend this browser can do. Safari's parser accepts
 * backdrop-filter: url() but it draws nothing (WebKit bug 245510), so the
 * engine has to be named here, not only feature-tested.
 */
export declare function detectBend(supports: (property: string, value: string) => boolean, userAgent: string): Bend;
type Listener = () => void;
/** The current mode. Stable between changes, so it works as a React store snapshot. */
export declare function getMode(): Mode;
/**
 * Which bend this browser could do, whatever the look is right now. Stays the same
 * for the page's life, so structure can depend on it without remounting anything.
 */
export declare function browserBend(): Bend;
/** Plain until the client knows better, so server markup and hydration always match. */
export declare const getServerMode: () => Mode;
export declare function subscribeMode(listener: Listener): () => void;
export declare function setPreferences(next: Partial<Preferences>): void;
export declare const getPreferences: () => Readonly<Preferences>;
/** Something broke for every bubble. The page goes plain at once and stays working. */
export declare function failGlass(reason: string, detail?: unknown): void;
/** The cause went away (a context came back): bubbles may try again. */
export declare function clearFailure(reason: string): void;
/** Reads the mode again, for tests and for a provider that wants a fresh look. */
export declare function readEnvironmentAgain(): void;
export {};
