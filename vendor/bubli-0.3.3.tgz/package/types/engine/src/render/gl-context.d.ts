declare const uniformNames: readonly ["uCenter", "uRadius", "uExtent", "uCorner", "uBevel", "uModeBasis", "uSquash", "uBow", "uTime", "uFlow", "uThickness", "uIridescence", "uDrainage", "uSwirl", "uOilCoverage", "uOilOpacity", "uOilEdge", "uOilLarge", "uOilFade", "uClearCenter", "uTint", "uSoapColor", "uCustomSoapPalette", "uSoapPaletteRed", "uSoapPaletteGold", "uSoapPaletteGreen", "uSoapPaletteCyan", "uSoapPaletteBlue", "uSoapPaletteViolet", "uSoapShadeColor", "uSoapHighlightColor", "uLightTheme", "uWindowLight", "uKeyLight", "uWindowTwin", "uWindowWidth", "uWindowGradient", "uTopFade", "uTopTail", "uTopLength", "uWindowHead", "uWindowTail", "uGlintShape", "uGlintSize", "uGlintIntensity", "uGlintOffset", "uWindowStyle", "uWindowLength", "uWindowMargin", "uWindowBend", "uWindowSize", "uWindowIntensity", "uTwinShape", "uSpark", "uBottomShade", "uShadeColor", "uFilmScale", "uReflectivity", "uMirage", "uFloorLight", "uReach", "uRefraction", "uGlass", "uDispersion", "uSeed", "uEnvironment", "uEnvRotation", "uHasBackdrop", "uPageTone", "uBackdropOrigin", "uBackdropScale", "uHasLayer", "uLayerRect", "uLayerCorner", "uLayerFill", "uLayerTrack", "uLayerFrom", "uLayerTo"];
export type BubbleUniform = (typeof uniformNames)[number];
type Location = WebGLUniformLocation | null;
export type BubbleUniforms = {
    f1: (location: Location, x: number) => void;
    f2: (location: Location, x: number, y: number) => void;
    f3: (location: Location, x: number, y: number, z: number) => void;
    f4: (location: Location, x: number, y: number, z: number, w: number) => void;
    v4: (location: Location, value: ArrayLike<number>) => void;
    i1: (location: Location, value: number) => void;
    m3: (location: Location, value: ArrayLike<number>) => void;
};
export type BubbleRect = {
    x: number;
    y: number;
    width: number;
    height: number;
};
export type BubbleContext = {
    gl: WebGL2RenderingContext;
    canvas: HTMLCanvasElement | OffscreenCanvas;
    u: Record<BubbleUniform, WebGLUniformLocation | null>;
    /**
     * Uniform setters that skip a value the program already holds. Every
     * surface draws with the one program, and most of a draw's values (its
     * whole material, when surfaces share one) repeat those of the draw
     * before, so most calls never reach the driver.
     */
    set: BubbleUniforms;
    /**
     * Reserves a region of the shared drawing buffer for one draw of this size
     * and points the viewport at it. Returns where the draw's bottom-left
     * corner lands, which it adds to its gl_FragCoord-based centre. With part,
     * only that rectangle of the draw (CSS-style, from the top left) is shaded
     * and later replaced; the rest of the surface's canvas keeps its pixels.
     */
    begin: (width: number, height: number, part?: BubbleRect | null) => [number, number];
    /**
     * Queues the last draw for its surface's own canvas; see flush. A context
     * that draws in its surface's canvas has nothing to hand over.
     */
    present: (surface: CanvasRenderingContext2D | null) => void;
    /** Present queued surfaces immediately when composed inside another canvas. */
    flush: () => void;
    /**
     * True once the program has linked. A paced context links on the driver's
     * own thread, and its surfaces wait for it instead of the page.
     */
    ready: () => boolean;
    /** Frames handed over that the GPU has not finished drawing yet. */
    inFlight: (now: number) => number;
};
export declare function sharedContext(): BubbleContext | null;
/** Takes the shared context away, for a demo or a test of what a real loss does. */
export declare function loseSharedContext(restoreAfter?: number): boolean;
/** Forgets the shared context so a restored page can build a fresh one. */
export declare function dropSharedContext(): void;
/**
 * The context a surface drawing in canvas should use: its own where that pays
 * and the limit allows, otherwise null for the shared one. A canvas keeps the
 * context it was first given, so a surface mounted on it again (as React does
 * in development) takes that context back.
 */
export declare function ownContext(canvas: HTMLCanvasElement): BubbleContext | null;
/** Frees the own context of a surface whose canvas has left the page. */
export declare function releaseCanvasContext(canvas: HTMLCanvasElement): void;
export declare function createBubbleContext(fragmentSource?: string, { paced, surface, }?: {
    paced?: boolean;
    /** A surface's own canvas, to draw in directly. */
    surface?: HTMLCanvasElement;
}): BubbleContext | null;
export {};
