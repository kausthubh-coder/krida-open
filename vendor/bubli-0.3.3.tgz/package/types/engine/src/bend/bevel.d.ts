/** Signed distance to a rounded rectangle centred on the origin; negative inside. */
export declare function roundedRectDistance(x: number, y: number, halfW: number, halfH: number, radius: number): number;
/**
 * How far a sample moves at this depth into the bevel, 0 to 1: furthest at the
 * rim, nothing on the flat face. Quadratic, so the field has no kink where the
 * face begins and never folds the picture over itself.
 */
export declare const bendAt: (x: number) => number;
/**
 * Displacement per pixel for a pill inside a padded square of width x height,
 * packed as 8-bit R (x) and G (y) around 128, the way feDisplacementMap reads
 * them. Vectors point outward along the rim, so the bevel squeezes in what lies
 * around the glass; the padding is where those samples land, so they are always
 * real pixels. Outside the pill nothing moves.
 */
export declare function displacementPixels(width: number, height: number, radius: number, bevel: number, pad?: number): Uint8ClampedArray<ArrayBuffer>;
/** Opacity per pixel for Safari's blur band: only the bevel blurs, the middle stays sharp. */
export declare function rimMaskPixels(width: number, height: number, radius: number, bevel: number): Uint8ClampedArray<ArrayBuffer>;
