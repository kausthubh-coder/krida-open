import { type BendVariant } from './bend/backend';
import type { Bend } from './capability/mode';
import { BubbleBody } from './physics/bubble-body';
import type { BodyPresetName } from './physics/presets';
import type { BubbleRect } from './render/gl-context';
import { type Material } from './render/material';
import { type Layer } from './render/surface';
export type BubbleState = 'warming' | 'bubble' | 'plain';
export type BubbleMotion = {
    clock: {
        time: number;
        spark: number;
    };
    body: ReturnType<BubbleBody['snapshot']>;
};
export type BubbleOptions = {
    /** The element whose box is the bubble. */
    host: HTMLElement;
    canvas: HTMLCanvasElement;
    /** Gets data-bubli-state; the whole control, when the host is only its thumb. */
    stateRoot?: HTMLElement;
    /** Where the pointer is felt; the host by default. */
    pointerTarget?: HTMLElement | null;
    bendLayer?: HTMLElement | null;
    bend: Bend;
    material: Partial<Material>;
    preset: BodyPresetName;
    light: boolean;
    still: boolean;
    /** Corner radius for the bend map, in pixels. */
    radius?: number;
    /** How far the bend may reach, in pixels. Small controls stay calm at the default. */
    bendMax?: number;
    /** Regular blurs what's behind so a label stays readable. Clear is a pure lens. */
    variant?: BendVariant;
};
export type Bubble = {
    body: BubbleBody;
    setMaterial: (material: Partial<Material>) => void;
    setLight: (light: boolean) => void;
    setStill: (still: boolean) => void;
    setBend: (bend: Bend) => void;
    setDormant: (dormant: boolean) => void;
    setLayer: (layer: Layer | null) => void;
    /** Draws as this box instead of its own. The radius keeps its frost's corners on it. */
    setShape: (shape: BubbleRect | null, radius?: number) => void;
    setBodyOpacity: (opacity: number | null) => void;
    /** The host moved inside its canvas. */
    moved: () => void;
    /** Wakes the drawing after the body was told something. */
    wake: () => void;
    /** Sets the thumb's own swell, which also grows the bend. */
    setSwell: (scale: number) => void;
    /** Carried at this velocity, in CSS pixels per second. */
    moveWith: (vx: number, vy: number) => void;
    motion: () => BubbleMotion | null;
    adopt: (motion: BubbleMotion) => void;
    state: () => BubbleState;
    dispose: () => void;
};
export declare function createBubble(options: BubbleOptions): Bubble;
