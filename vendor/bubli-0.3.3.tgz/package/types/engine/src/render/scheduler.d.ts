export type Task = (now: number) => void;
export declare function requestFrame(task: Task): void;
/**
 * For springs that move things. These run before the draws, so a bubble they move is
 * drawn in the same frame as what's written on it. Otherwise it trails by a frame, and
 * the glass reads as lagging behind its own text.
 */
export declare function requestMotionFrame(task: Task): void;
export declare function cancelFrame(task: Task): void;
/** The rate for something being touched, whatever the idle film is doing. */
export declare const isQuickFrame: () => boolean;
export declare const isFilmFrame: () => boolean;
export declare const setDrifting: (id: number, on: boolean) => void;
export declare function isFilmTurn(id: number): boolean;
export declare const currentResolution: () => number;
export declare function onResolution(listener: () => void): () => void;
/** Time from handing a frame over to its last pixel. Reported, not acted on. */
export declare function gpuDone(latency: number): void;
/** Live counts for the performance page and the benchmark. */
export declare const stats: {
    frames: number;
    filmDraws: number;
    fullDraws: number;
    /** Draws per bubble id this frame, to prove it never exceeds one. */
    maxDrawsPerBubble: number;
    mainMs: number;
    lastGpuLatency: number;
    /** Pixels shaded and copied, which is what a weak GPU feels. */
    pixels: number;
    /** How wide the shared buffer is: copies read all of it back in some browsers. */
    bufferWidth: number;
    /** The most bubbles that drew for the first time in one frame. */
    maxFirstDraws: number;
};
export declare const firstDrawDue: () => boolean;
export declare function countFirstDraw(): void;
export declare function countDraw(id: number, film: boolean, pixels: number): void;
export declare const setPacer: (inFlight: ((now: number) => number) | null) => void;
/** The shared context is gone. Plain at once; one recovery is allowed, a second loss sticks. */
export declare function contextLost(): void;
export declare function contextRestored(): void;
