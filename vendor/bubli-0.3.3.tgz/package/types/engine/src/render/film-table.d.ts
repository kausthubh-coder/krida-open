export declare function filmTable(): Float32Array<ArrayBufferLike>;
export declare function noiseVolume(): Uint8Array<ArrayBufferLike>;
