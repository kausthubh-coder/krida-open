import { type SpringConfig } from './physics/spring';
export type RunningSpring = {
    /** Where it's headed, and optionally a fresh velocity. */
    to: (target: number, velocity?: number) => void;
    /** Jumps there with no motion. */
    set: (value: number) => void;
    setConfig: (config: SpringConfig) => void;
    value: () => number;
    velocity: () => number;
    stop: () => void;
};
export declare function runSpring(options: {
    from: number;
    config: SpringConfig;
    /** Reduced motion: every change lands at once. */
    still?: () => boolean;
    epsilon?: number;
    onUpdate: (value: number, velocity: number) => void;
    onRest?: (value: number) => void;
}): RunningSpring;
