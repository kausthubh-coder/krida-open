import { type Surface } from '../../engine/src/index';
import { type CSSProperties, type ReactNode } from 'react';
export type LensBarItem = {
    key: string;
    label: ReactNode;
    icon?: ReactNode;
    href?: string;
    disabled?: boolean;
};
type LensBarProps = {
    name: 'bottom-nav' | 'tab-bar' | 'segmented';
    items: LensBarItem[];
    value: string;
    onChange: (key: string) => void;
    /** How items announce themselves. */
    role: 'tab' | 'radio' | 'link';
    containerRole?: 'tablist' | 'radiogroup';
    containerLabel: string;
    /** Frosted bar around the lens, or nothing but the track. */
    frosted?: boolean;
    iconsAbove?: boolean;
    /** What the bar is made of, over the theme's. */
    surface?: Surface;
    /** Links stay links, but a plain click goes to onChange, for a client-side router. */
    clientNavigation?: boolean;
    className?: string;
    style?: CSSProperties;
};
export declare function LensBar({ name, items, value, onChange, role, containerRole, containerLabel, frosted, iconsAbove, surface, clientNavigation, className, style, }: LensBarProps): import("react").JSX.Element;
export {};
