export declare const FIREFOX_BEND_BUDGET = 1;
/** A struggling page gives up its costliest effect first. */
export declare function setBendBudget(next: number): void;
export type BendClaim = {
    visible: boolean;
    /** The pointer or a finger is on it right now. */
    active: boolean;
    /** Distance from the viewport's centre, in pixels. */
    distance: number;
    grant: (live: boolean) => void;
};
/** Pure: who gets a slot. */
export declare function allocate(claims: BendClaim[], slots: number): Set<BendClaim>;
export declare function rebalance(): void;
export declare function addClaim(claim: BendClaim): () => void;
