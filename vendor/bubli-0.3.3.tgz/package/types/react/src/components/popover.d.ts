import type { Placement } from '@floating-ui/dom';
import { type ReactElement, type ReactNode } from 'react';
export type PopoverProps = {
    /** The element that opens it: one element taking a ref and onClick (a Button works). */
    trigger: ReactElement<{
        ref?: unknown;
        onClick?: () => void;
        'aria-expanded'?: boolean;
        'aria-haspopup'?: 'dialog';
        'aria-controls'?: string;
    }>;
    /** Names the panel for screen readers. */
    label: string;
    placement?: Placement;
    children: ReactNode;
};
/** A small frosted panel next to its trigger, growing out of it. Not modal. */
export declare function Popover({ trigger, label, placement, children }: PopoverProps): import("react").JSX.Element;
export type TooltipProps = {
    /** What it says. */
    content: ReactNode;
    children: ReactElement<{
        'aria-describedby'?: string;
        onPointerEnter?: () => void;
        onPointerLeave?: () => void;
        onFocus?: () => void;
        onBlur?: () => void;
        ref?: unknown;
    }>;
    placement?: Placement;
};
/** A short plain label on hover or keyboard focus. Too small and too brief to be a bubble. */
export declare function Tooltip({ content, children, placement }: TooltipProps): import("react").JSX.Element;
