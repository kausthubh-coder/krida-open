import { type BendVariant, type BodyPresetName, type Bubble, type Material, type Surface } from '../../engine/src/index';
import { type RefObject } from 'react';
import { type BubbleFamily } from './provider';
/** glass: the soap film. liquid: Apple's clear glass. frosted and bar: its panel and bar bodies. */
export type BubbleLook = 'glass' | 'liquid' | 'frosted' | 'bar';
export type UseBubbleOptions = {
    host: RefObject<HTMLElement | null>;
    canvas: RefObject<HTMLCanvasElement | null>;
    stateRoot?: RefObject<HTMLElement | null>;
    pointerTarget?: RefObject<HTMLElement | null>;
    bendLayer?: RefObject<HTMLElement | null>;
    preset?: BodyPresetName;
    look?: BubbleLook;
    material?: Partial<Material>;
    /** How far the bend may reach, in pixels. */
    bendMax?: number;
    /** Regular blurs what's behind so a label stays readable. Clear is a pure lens. */
    variant?: BendVariant;
    /** Called once per bubble, after it exists. */
    onReady?: (bubble: Bubble) => void;
    /** A panel draws its own bubble even inside another flat area. */
    ignoreFlat?: boolean;
    /** What a bar or panel is made of, over the theme's. */
    surface?: Surface;
    /** Which of the theme's tune applies. Left out, it follows the look. */
    family?: BubbleFamily;
};
/** One bubble's life: created in the browser, replaced when the look changes, gone when plain. */
export declare function useBubble({ host, canvas, stateRoot, pointerTarget, bendLayer, preset, look, material, bendMax, variant, onReady, ignoreFlat, surface: ownSurface, family, }: UseBubbleOptions): {
    bubble: RefObject<Bubble | null>;
    mode: import("@bubli/engine").Mode;
    theme: import("@bubli/engine").Theme;
    material: {
        radius?: number | undefined;
        bevel?: number | undefined;
        thickness?: number | undefined;
        iridescence?: number | undefined;
        drainage?: number | undefined;
        swirl?: number | undefined;
        filmScale?: number | undefined;
        oilOpacity?: number | undefined;
        oilCoverage?: number | undefined;
        oilEdge?: number | undefined;
        oilEdgeFade?: number | undefined;
        clearCenter?: number | undefined;
        tint?: string | undefined;
        soapColor?: string | undefined;
        soapPalette?: "natural" | "custom" | undefined;
        soapPaletteRed?: string | undefined;
        soapPaletteGold?: string | undefined;
        soapPaletteGreen?: string | undefined;
        soapPaletteCyan?: string | undefined;
        soapPaletteBlue?: string | undefined;
        soapPaletteViolet?: string | undefined;
        soapShadeColor?: string | undefined;
        soapHighlightColor?: string | undefined;
        reflectivity?: number | undefined;
        mirage?: number | undefined;
        seeThrough?: number | undefined;
        seeThroughBend?: number | undefined;
        opacity?: number | undefined;
        floorLight?: number | undefined;
        windowLight?: boolean | undefined;
        windowStyle?: "bubble" | "edge" | undefined;
        windowLength?: number | undefined;
        windowMargin?: number | undefined;
        windowBend?: number | undefined;
        windowSize?: number | undefined;
        windowWidth?: number | undefined;
        topFade?: number | undefined;
        topTail?: number | undefined;
        topLength?: number | undefined;
        windowGradient?: number | undefined;
        windowHead?: number | undefined;
        windowTail?: number | undefined;
        glintShape?: "none" | "auto" | "dot" | "dash" | "pair" | undefined;
        glintSize?: number | undefined;
        glintIntensity?: number | undefined;
        glintDistance?: number | undefined;
        glintHeight?: number | undefined;
        windowIntensity?: number | undefined;
        windowTwin?: boolean | undefined;
        windowTwinShape?: "dot" | "arc" | "crescent" | "streak" | "mirror" | undefined;
        keyLight?: boolean | undefined;
        bottomShade?: boolean | undefined;
        bottomShadeColor?: string | undefined;
        reach?: number | undefined;
        refraction?: number | undefined;
        glass?: number | undefined;
        dispersion?: number | undefined;
        environment?: "studio" | "window" | "sky" | "soft" | undefined;
        tilt?: number | undefined;
        wobble?: number | undefined;
        speed?: number | undefined;
        paused?: boolean | undefined;
        seed?: number | undefined;
        maxDpr?: number | undefined;
    };
    surface: Surface;
};
