import type { Material } from '../../engine/src/index';
import { type HTMLAttributes, type Ref } from 'react';
export type SliderProps = Omit<HTMLAttributes<HTMLDivElement>, 'onChange' | 'defaultValue'> & {
    ref?: Ref<HTMLDivElement>;
    value?: number;
    defaultValue?: number;
    min?: number;
    max?: number;
    step?: number;
    onValueChange?: (value: number) => void;
    /** Fill colour at the start of the track. */
    from?: string;
    /** Fill colour at the end of the track; defaults to from. */
    to?: string;
    disabled?: boolean;
    /** Accessible name. */
    label?: string;
    /** 1 is a 38 x 26 px thumb. */
    scale?: number;
    material?: Partial<Material>;
};
/**
 * A slider whose thumb sits exactly at the value and lenses the fill. A native
 * range input on top carries keyboard, touch and screen readers; the thumb only
 * swells while dragged. It never chases the pointer on a spring.
 */
export declare function Slider({ ref, value, defaultValue, min, max, step, onValueChange, from, to, disabled, label, scale, material, className, style, ...rest }: SliderProps): import("react").JSX.Element;
