import { type Material } from '../../engine/src/index';
import { type InputHTMLAttributes, type Ref } from 'react';
export type SearchProps = Omit<InputHTMLAttributes<HTMLInputElement>, 'size'> & {
    ref?: Ref<HTMLInputElement>;
    /** Starts as a round button that turns into the field. */
    collapsible?: boolean;
    /** The side a collapsed search sits on and grows from. */
    align?: 'start' | 'end';
    material?: Partial<Material>;
};
/**
 * A search field in a bubble pill. It wobbles under the pointer, gentler than a
 * button, and swells on press. Collapsible, it starts as a round button and turns
 * fluidly into the pill; it takes its full width in layout from the start, so
 * nothing around it moves while it grows.
 */
export declare function Search({ ref, collapsible, align, material, className, style, placeholder, 'aria-label': label, value, defaultValue, onChange, onFocus, onBlur, ...rest }: SearchProps): import("react").JSX.Element;
