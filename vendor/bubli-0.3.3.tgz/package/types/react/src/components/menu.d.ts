import type { Material } from '../../engine/src/index';
import { type ReactNode } from 'react';
type Action = {
    type?: 'item';
    label: ReactNode;
    icon?: ReactNode;
    shortcut?: string;
    danger?: boolean;
    disabled?: boolean;
    /** A checkable item: shown with a mark and announced as a radio. */
    checked?: boolean;
    /** For type-ahead when label isn't plain text. */
    textValue?: string;
    onSelect?: () => void;
};
export type MenuItem = Action | {
    type: 'separator';
} | {
    type: 'heading';
    label: ReactNode;
};
export type MenuProps = {
    /** Content of the trigger button. */
    label: ReactNode;
    /** Name of the trigger; needed when label is an icon. */
    triggerLabel?: string;
    /** A round icon trigger instead of a pill. */
    round?: boolean;
    items: MenuItem[];
    /** Edge of the trigger the menu grows from. */
    align?: 'start' | 'end';
    /** Which way it opens; it flips when there's no room. */
    side?: 'bottom' | 'top';
    material?: Partial<Material>;
    className?: string;
};
/** A button that grows into a frosted panel of actions and shrinks back into it. */
export declare function Menu({ label, triggerLabel, round, items, align, side, material, className, }: MenuProps): import("react").JSX.Element;
export type ContextMenuProps = {
    items: MenuItem[];
    label?: string;
    children: ReactNode;
    className?: string;
    /** How long a finger stays down to open it, in ms. */
    longPress?: number;
};
/** Right-click, the menu key or a long press opens a menu that grows from that very spot. */
export declare function ContextMenu({ items, label, children, className, longPress, }: ContextMenuProps): import("react").JSX.Element;
export {};
