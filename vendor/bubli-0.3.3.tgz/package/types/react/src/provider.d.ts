import { type Material, type Surface, type GlassPreference, type BendPreference, type Mode, type Theme, type SpringConfig } from '../../engine/src/index';
import { type CSSProperties, type HTMLAttributes, type ReactNode, type RefObject, useEffect } from 'react';
export declare const useIsomorphicLayoutEffect: typeof useEffect;
type BubliContextValue = {
    mode: Mode;
    theme: Theme;
    root: RefObject<HTMLDivElement | null>;
};
export type BubliProviderProps = {
    children?: ReactNode;
    /** Force the look. Left out: bubble when the device can, otherwise plain. */
    glass?: GlassPreference;
    /** Turn the bend under rims off. */
    bend?: BendPreference;
    /** Remember the user's choices between visits (see useBubliMode). */
    persist?: boolean;
    className?: string;
    style?: CSSProperties;
};
/** Wrap the app once. Holds the look (bubble or plain) and the theme. */
export declare function BubliProvider({ children, glass, bend, persist, className, style, }: BubliProviderProps): import("react").JSX.Element;
export type BubliMotion = 'calm' | 'default' | 'lively';
/** The families of bubbles bigger than a button. Each can look its own way. */
export type BubbleFamily = 'menu' | 'bar' | 'sheet' | 'toast' | 'dialog';
export type BubbleDials = {
    /** How much tint fills the body, 0 to 1. */
    opacity?: number;
    /** Blur of what's behind, in pixels. */
    frost?: number;
    /** How strong the film's colours are. */
    iridescence?: number;
    /** How bright the highlights are. */
    reflectivity?: number;
    /** How far the middle stays free of film, 0 to 1. */
    clearCenter?: number;
    /** How wide the lens at the edge is, in pixels. */
    bevel?: number;
    /** How much it rings when touched or opened. */
    wobble?: number;
    /** Whether the film drifts at rest. Off costs no drawing. */
    filmMoves?: boolean;
    /** How fast a menu or popover grows. */
    stiffness?: number;
    /** How much it settles as it lands. Lower overshoots more. */
    damping?: number;
};
export type BubbleTune = Partial<Record<Theme, Partial<Record<BubbleFamily, BubbleDials>>>>;
export type BubliThemeProps = {
    /**
     * How strong the film is at edges, 0 to 1: about 0.5 is the default, lower for a
     * text-heavy app that should stay quiet, higher for a media one.
     */
    rim?: number;
    /** Over the bubble material of small controls: thickness, oil, reflections. */
    material?: Partial<Material>;
    /** Over the frosted material of panels. */
    panelMaterial?: Partial<Material>;
    /** What bars and panels are made of: bubble (the default), liquid, soap or solid. */
    surface?: Surface;
    /**
     * This app's numbers for every bubble bigger than a button, per theme: what /tune on
     * bubli's site copies. Anything left out keeps the kit's default.
     */
    tune?: BubbleTune;
    /** How a menu or popover grows and shrinks, over everything else. */
    morph?: {
        open?: SpringConfig;
        close?: SpringConfig;
    };
    /** Light or dark for this part of the page, as with player controls over video. */
    theme?: Theme;
    /**
     * The colour behind these controls, when it isn't their background: over a video,
     * pass the video's rough tone, such as #000.
     */
    tone?: string;
    /** How much things wobble and swell. */
    motion?: BubliMotion;
    /** The accent: active tab, selected chip, focus ring. */
    accent?: string;
    /** Corner radius of buttons and chips, in pixels. Left out, they're full pills. */
    controlRadius?: number;
    /** Any --bubli-* token, for the host app's radii, surfaces and text colours. */
    tokens?: Record<`--bubli-${string}`, string>;
    children?: ReactNode;
};
type ThemeValue = {
    tune?: BubbleTune;
    morph?: {
        open?: SpringConfig;
        close?: SpringConfig;
    };
    material?: Partial<Material>;
    panelMaterial?: Partial<Material>;
    /** The theme's CSS variables, for AboveScene's portal, which leaves its DOM. */
    variables?: CSSProperties;
    surface?: Surface;
    theme?: Theme;
};
export declare const useBubliTheme: () => ThemeValue;
/**
 * Fit bubli to an app: its accent, radii, surfaces and how lively it should feel.
 * Goes anywhere under the provider, and nests.
 */
export declare function BubliTheme({ rim, material, panelMaterial, surface, tune, morph, theme, tone, motion, accent, controlRadius, tokens, children, }: BubliThemeProps): import("react").JSX.Element;
/**
 * Controls inside this draw plain fills, with no bubble of their own: no glass on
 * glass. Panels and nav bars already use it.
 */
export declare function BubliFlat({ children }: {
    children?: ReactNode;
}): import("react").JSX.Element;
export declare const useFlat: () => boolean;
/** The look, theme and root; plain outside a provider, so components never crash there. */
export declare function useBubli(): BubliContextValue;
/** Read and change the look from anywhere, as a settings switch would. */
export declare function useBubliMode(): {
    mode: Mode;
    setGlass(glass: GlassPreference): void;
    setBend(bend: BendPreference): void;
};
export type BubliSceneProps = HTMLAttributes<HTMLDivElement> & {
    children?: ReactNode;
};
/**
 * What floating bubbles bend in Firefox, which draws this element into their
 * bend. Keep nav bars and other floating controls outside it. Other browsers
 * don't need it; everywhere it's just a div.
 */
export declare function BubliScene({ children, ...rest }: BubliSceneProps): import("react").JSX.Element;
/** Whether this control floats over content, so a bend has something to bend. */
export declare const useFloating: () => boolean;
export declare function AboveScene({ children }: {
    children?: ReactNode;
}): import("react").JSX.Element;
export {};
