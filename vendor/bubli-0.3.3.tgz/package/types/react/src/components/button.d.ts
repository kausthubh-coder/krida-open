import type { BendVariant, Material } from '../../engine/src/index';
import type { ButtonHTMLAttributes, ReactNode, Ref } from 'react';
export type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
    ref?: Ref<HTMLElement>;
    /** Colour of the bubble body, for the one main action on a screen. */
    tint?: string;
    size?: 'sm' | 'md' | 'lg';
    material?: Partial<Material>;
    icon?: ReactNode;
    /** Bend what's behind it. By default it does only when floating over content. */
    bend?: boolean;
    /** Regular blurs what's behind so a label stays readable. Clear is a pure lens, for over a picture. */
    variant?: BendVariant;
};
/** A pill sized by its content. Pressing swells the bubble; the label barely moves. */
export declare function Button({ ref, tint, size, material, icon, bend, className, style, children, type, ...rest }: ButtonProps): import("react").JSX.Element;
export type IconButtonProps = Omit<ButtonProps, 'icon'> & {
    /** Icon buttons have no text, so they need a name. */
    'aria-label': string;
};
/** A round button for one icon. */
export declare function IconButton({ ref, tint, size, material, bend, className, style, children, type, ...rest }: IconButtonProps): import("react").JSX.Element;
