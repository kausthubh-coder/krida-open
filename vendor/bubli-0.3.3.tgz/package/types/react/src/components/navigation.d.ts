import type { Surface } from '../../engine/src/index';
import type { CSSProperties, HTMLAttributes, ReactNode } from 'react';
import { type LensBarItem } from './lens-bar';
type Selectable = {
    /** What the bar is made of, over the theme's: liquid, soap, solid or bubble. */
    surface?: Surface;
    items: LensBarItem[];
    value?: string;
    defaultValue?: string;
    onValueChange?: (key: string) => void;
    'aria-label'?: string;
    className?: string;
    style?: CSSProperties;
};
/** The floating bar at the bottom of a phone screen: a frosted pill with a lens on the current page. */
export declare function BottomNav(props: Selectable): import("react").JSX.Element;
/** Tabs that switch a view in place: a frosted pill, arrow keys inside, one stop in the tab order. */
export declare function TabBar(props: Selectable): import("react").JSX.Element;
/** A few mutually exclusive choices side by side. */
export declare function SegmentedControl(props: Selectable): import("react").JSX.Element;
export type TopNavProps = Omit<HTMLAttributes<HTMLElement>, 'title'> & {
    title?: ReactNode;
    leading?: ReactNode;
    trailing?: ReactNode;
    /** A floating pill instead of a full-width bar. */
    floating?: boolean;
    /** Floating only: what the bar is made of, over the theme's. */
    surface?: Surface;
};
/**
 * The bar at the top. Floating, it's a glass pill like the bottom nav. Full width,
 * it's a plain frosted strip: too big for a film rim.
 */
export declare function TopNav({ title, leading, trailing, floating, surface, className, children, ...rest }: TopNavProps): import("react").JSX.Element;
/** Content fades and blurs into a floating bar. Put one beside each fixed bar. */
export declare function ScrollEdge({ side }: {
    side?: 'top' | 'bottom';
}): import("react").JSX.Element;
export {};
