/** Joins class names, skipping the empty ones. */
export declare const cx: (...names: (string | false | null | undefined)[]) => string;
