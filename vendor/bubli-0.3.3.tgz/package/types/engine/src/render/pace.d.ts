export type PaceStep = {
    kind: 'shed-bend';
    budget: number;
} | {
    kind: 'slow-film';
    level: number;
} | {
    kind: 'lower-resolution';
    level: number;
} | {
    kind: 'go-plain';
};
/** What gets given up, in order: the costliest thing first, the look itself only at the very end. */
export declare const PACE_LADDER: PaceStep[];
export declare class Pacer {
    private intervals;
    private windowStart;
    private last;
    private slowSpells;
    private hopelessSpells;
    private step;
    /** Time since the frame before this one, in ms. */
    lastInterval: number;
    /** Call once per animation frame. Returns what to give up now, if anything. */
    frame(now: number): PaceStep | null;
}
