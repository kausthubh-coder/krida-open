---

name: use-bubli
description: Add bubli (soap-bubble glass React controls) to an existing app, fitted to that app's own design. Use when asked to add bubli or bubble or liquid glass controls, or to check how bubli looks and feels in a project.
---

# use-bubli

bubli is a React kit of controls drawn as thin-film bubbles, on a soft-body physics engine. It falls back to a solid plain look when a browser can't draw them.

The job is **bubli fitted to this app**, not this app rebuilt in bubli. The usual failure: an agent ports every screen to bubble components and leaves the app looking weird. A good result looks like the app's own designers chose a few glass controls.

Work through the steps in order. Each ends on something you can check.

## 1. Read the host app's design

Before installing anything, read and write down, in a short note for yourself:

- Its tokens: colours, radii, font, type scale, spacing. Where they live (Tailwind config, CSS variables, theme file).
- How it does dark mode. bubli follows `data-theme="dark"` on an ancestor, else `prefers-color-scheme`. A `class="dark"` app needs `data-theme` set beside it.
- Its density and its corners: a sharp, dense admin tool wants much less glass than a round, airy consumer app.
- Which UI library it uses for dialogs and menus, and whether its controls already work well.

Screenshot the screens you'll touch at desktop and phone widths, light and dark. These are the before shots.

Done when you can name the app's radius scale, accent, font and dark-mode switch.

## 2. Choose where glass goes

Bubbles look great small and bad big. Choose few places. Propose them before changing many screens, if your user is around.

| Good fits                                    | Keep the app's own                  |
| -------------------------------------------- | ----------------------------------- |
| A floating bottom nav or tab bar             | Tables, forms, dense lists          |
| Floating action buttons, toolbars over media | Cards, sidebars, big panels         |
| The primary button on a key screen           | Rows of secondary buttons           |
| Toggles and sliders in settings or players   | Dialogs the app already has working |

Rules, which the kit mostly enforces:

- Controls, bars and panels are bubbles, with a little frost where there's text on them. Rows get a plain shade.
- No glass on glass: controls inside bubli panels turn into plain fills automatically.
- One tinted action per view.
- Over a busy background, use floating bars and blur (`variant="regular"`, the default). `variant="clear"` is a pure lens, for bubbles with nothing written on them.

Done when you have a short list of controls to change, and everything else stays as it is.

## 3. Install

The repo is private, so vendor the package. This needs `gh` signed in with access once, and then nothing at build time, so it also works on Vercel:

```sh
mkdir -p vendor
gh release download -R kausthubh-coder/bubli -p 'bubli-*.tgz' -D vendor --clobber
bun add "./vendor/$(ls vendor | grep '^bubli-' | sort -V | tail -1)"
```

Commit `vendor/`. Wrap the app once, and import bubli's stylesheet **before** the app's own, so the app's overrides win. bubli's rules are plain class selectors in no CSS layer.

```tsx
import { BubliProvider, BubliTheme, ToastProvider } from 'bubli';
import 'bubli/styles.css';
import './globals.css';

<BubliProvider persist>
  <BubliTheme accent="#..." motion="default" controlRadius={12} rim={0.5}>
    <ToastProvider>{children}</ToastProvider>
  </BubliTheme>
</BubliProvider>;
```

`bubli` is marked `'use client'`, so in Next.js app router it works from a server layout.

Done when the app builds and a bubli `Button` renders.

## 4. Fit it to the app

This is the step that stops it looking off. Map the note from step 1 onto `BubliTheme`:

- `accent`: the app's accent. For one per colour scheme, set `--bubli-accent` on `.bubli-root` in the app's CSS instead.
- `controlRadius`: leave it out for pills. Set it for an app with square-ish corners, in pixels.
- `rim`: 0 to 1, how strong the edge of bars and panels is. Low for text-heavy apps, high for media ones.
- `tokens`: `--bubli-fg`, `--bubli-fg-soft`, `--bubli-plain`, `--bubli-plain-edge`, `--bubli-panel`, `--bubli-panel-edge`, `--bubli-shade`, `--bubli-card-radius`, `--bubli-row-radius`, `--bubli-button-weight`, and for bars `--bubli-lens-rest`, `--bubli-lens-rest-edge`, `--bubli-lens-inset`, `--bubli-bubble-frost`, `--bubli-bubble-bar-frost`.
- `motion`: `calm` for serious or dense apps, `default` for most, `lively` for playful consumer ones.
- `surface`: what bars and panels are made of. `bubble` (the default) is the small controls' film and wobble on a bigger shape, a bit frosted. `liquid` is clear glass with a bright rim, `soap` adds film to that rim, `solid` has no blur or bend. Set it on `BubliTheme` for the app or a part of it, or on one bar or `Glass`.
- `tune`: this app's numbers for every bubble bigger than a button, per theme and family (`menu`, `bar`, `sheet`, `toast`, `dialog`). It applies to the `bubble` surface, and anything left out keeps the default, so start with none and add only what looks off in this app:

  ```tsx
  <BubliTheme tune={{ dark: { menu: { opacity: 0.8, frost: 20 }, bar: { filmMoves: false } } }}>
  ```

  Each family takes `opacity` (how solid), `frost` (blur in pixels), `iridescence` and `reflectivity` (rim colour and light), `clearCenter`, `bevel` (rim width), `wobble`, `filmMoves`, and, for menus, `stiffness` and `damping` (how they grow). `/tune` on bubli's site sets them all by eye and copies the value.
- `material`: lower `iridescence` (try 0.25) to quiet the rainbow in a restrained brand.
- Size: buttons, chips and search scale with the parent's font size. `Toggle` and `Slider` take `scale`. Match the app's control height.

Controls inherit the app's font; don't set one. Keep the app's icons.

Plain mode has to fit too, since some users get it. Turn it on (`<BubliProvider glass="plain">`) and check the controls still look like this app's. Fix with tokens, not by overriding bubli's classes.

Done when, in plain mode, a bubli control next to one of the app's own looks like they belong together.

## 5. Use the right component

`Button`, `IconButton` (needs `aria-label`), `Toggle`, `Slider`, `Search` (`collapsible` for the expanding one), `Chip`, `Stepper`, `Progress`, `Card`, `ListRow`, `Menu`, `ContextMenu`, `Popover`, `Tooltip`, `Dialog`, `Sheet`, `useToast`, `BottomNav`, `TabBar`, `SegmentedControl`, `TopNav`, `ScrollEdge`. `Glass` builds your own. Full props are in `node_modules/bubli/types/react/src/components/`.

The ones that trip people up:

- `BottomNav`, `TabBar`, `SegmentedControl`: `items={[{ key, label, icon?, href?, disabled? }]}`, with `value` or `defaultValue` and `onValueChange`.
- With a router, give items `href` and pass `onValueChange={(key) => router.push(key)}`. They stay real links, and a plain click goes to your router instead of reloading.
- `Menu`: `label`, `items={[{ label, icon?, shortcut?, danger?, checked?, onSelect? }, { type: 'separator' }]}`, `round` with `triggerLabel` for an icon trigger, `align`, `side`.
- `TopNav`: `floating` for the pill, with `leading`, `title`, `trailing`.
- Beside each fixed bar, put a `ScrollEdge side="top"` or `"bottom"`, so text doesn't run legibly behind it.

- Leave sizes, motion and hit areas to the kit. Don't CSS-`transform` a bubli control or its parent while it animates: wobble and swell are drawn at real size. Move things with layout or `translate` only.
- Don't set `overflow: hidden` right around a control: the bubble draws past its box.
- Floating over content, wrap controls in `<AboveScene>` and the page's content in `<BubliScene>`: Firefox can only bend what the bubble isn't inside. In Firefox, `AboveScene` moves its children outside their DOM parent, so don't rely on a parent's `closest()`, event bubbling or test scoping there. Everywhere else, `bend` isn't needed in a page's flow, where it sits on a flat surface and just costs GPU.

### Controls over a video

Controls work over a playing `<video>`. Keep them dark whatever the page's theme is, and tell them what's behind them, since they can't read a video's colour:

```tsx
<BubliTheme theme="dark" tone="#101014" accent="#ffffff">
  <div className="player">
    <video />
    {controls}
  </div>
</BubliTheme>;
```

- Put `overflow: hidden` on the video's own box or on the player's frame, never right around a control.
- Put the sliders and small buttons in a `Glass look="bar" preset="bar" bend variant="bar"`. Don't wrap them in `BubliFlat` here: over a picture the owner wants glass thumbs and see-through buttons, and it's the one place glass sits on glass.
- Round buttons floating on the picture take `variant="clear"` if they bend. The default, `regular`, adds a blur, and in Firefox a dark backing, which reads as an opaque dark disc over a video.
- `/player` on bubli's site is a working example, with all four surfaces and a frame-rate reading.
- A video repaints whatever blurs it, on every video frame. Measure frame gaps in a real window on a weak GPU. If it drops frames, set `surface="solid"` on the bar before removing anything else.

## 6. Prove the look

Run the app and screenshot each changed screen at desktop (1280) and phone (390) widths, light and dark, in Chromium, Firefox and WebKit, and **look at every image**. Compare with the before shots:

- [ ] It still looks like this app. Same font, corners, density, colours.
- [ ] Text on or near glass is readable, in both themes.
- [ ] No rainbow on anything big. Nothing clipped at a bubble's edge.
- [ ] Nothing moved that you didn't mean to move. No sideways scroll on a phone.
- [ ] Plain mode looks deliberate.

If it looks off, remove glass before adding tweaks. The usual fix is fewer bubbles.

## 7. Prove the feel

Screenshots can't show this. Drive it with Playwright and read the numbers, and capture frames during motion:

- Press a button: the swell starts immediately, and the hit box doesn't move. `getBoundingClientRect` on it should be identical while pressed.
- Open a menu: screenshots at 60, 120 and 240 ms show it growing out of its button. Its growth is drawn, so its DOM size doesn't change: only a screenshot shows it. Item heights must stay the same throughout. On a mouse click focus lands on the menu itself, and arrows then move through items.
- Drag a slider: the thumb sits at the value with no lag.
- Tab bar: pressing lifts the lens at once; it slides, then settles to a quiet pill.
- Type in search: a ripple at the caret that settles, not a field that grows.
- Performance: `import { stats } from 'bubli/engine'`, and read it on a real screen. `stats.maxDrawsPerBubble` must be 1. Sample `requestAnimationFrame` gaps while hovering and opening menus: 60 fps on a normal machine, with under 5% of frames over 20 ms. If it lags, use fewer bubbles on that screen first.
- Measure lag in a real browser window on the real machine: headless Firefox can't show it (its animation frames run far faster than a display and it may not draw backdrop blur), and a fast Mac's GPU hides what a laptop's shows.
- Failure: block WebGL with `<BubliProvider glass="plain">`, and set `prefers-reduced-motion`. Everything must keep working.

Report what you ran and saw, what you changed in the app, and what you didn't check.
