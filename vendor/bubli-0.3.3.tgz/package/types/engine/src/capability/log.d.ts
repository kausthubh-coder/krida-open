/** A broken bubble falls back silently and says why once per session. */
export declare function warnOnce(reason: string, detail?: unknown): void;
