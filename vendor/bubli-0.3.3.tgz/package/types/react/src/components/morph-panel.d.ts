import { type Bubble, type BubbleRect, type Material } from '../../engine/src/index';
import { type Placement } from '@floating-ui/dom';
import { type HTMLAttributes, type ReactNode, type Ref, type RefObject } from 'react';
import { type BubbleFamily } from '../provider';
export type MorphPanelProps = HTMLAttributes<HTMLDivElement> & {
    ref?: Ref<HTMLDivElement>;
    open: boolean;
    /** What it grows out of. A rect, or the element whose box it starts from. */
    from: RefObject<HTMLElement | null> | (() => BubbleRect);
    placement?: Placement;
    /** Distance from the anchor; negative slides the panel over it, so the trigger becomes the panel. */
    gap?: number;
    /** Corner radius when open, in pixels. */
    radius?: number;
    material?: Partial<Material>;
    /** The trigger's bubble, whose wobble and film the panel carries on. */
    handOver?: RefObject<Bubble | null>;
    /** Shown over the panel's start, fading as the content comes in: the trigger's own label. */
    echo?: ReactNode;
    /** Called when the close animation has finished and the panel is gone. */
    onClosed?: () => void;
    /** Called as soon as the panel is placed and can take focus. */
    onPlaced?: () => void;
    /** Called when the panel has reached its open size. */
    onOpened?: () => void;
    /** Don't use the popover top layer: the panel is placed by its parent (a dialog). */
    inline?: boolean;
    /** Which of the theme's tune applies. */
    family?: BubbleFamily;
    children?: ReactNode;
};
/**
 * A frosted panel that grows out of the thing that opened it and shrinks back
 * into it. Layout never changes during the morph: the panel takes its open size
 * at once, the bubble is drawn at the in-between size, and a clip follows it.
 * The content keeps its size throughout, so text never scales.
 */
export declare function MorphPanel({ ref, open, from, placement, gap, radius, material, handOver, echo, onClosed, onPlaced, onOpened, inline, family, className, style, children, ...rest }: MorphPanelProps): import("react").JSX.Element;
