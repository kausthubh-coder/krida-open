export declare const spectralSamples = 16;
/** Thickest film in the lookup table, nm; thicker films have washed out to white. */
export declare const filmMax = 3000;
/** Lookup table size: thickness samples × incidence samples. */
export declare const filmSize: readonly [768, 48];
/** The baked noise repeats every this many units, in this many texels. */
export declare const noisePeriod = 8;
export declare const noiseSize = 64;
export declare const bubbleVertex = "#version 300 es\nlayout(location = 0) in vec2 aPosition;\nvoid main() {\n  gl_Position = vec4(aPosition, 0.0, 1.0);\n}\n";
export declare const bubbleFragment: string;
/** The complete material with another silhouette's SDF. */
export declare function bubbleFragmentForOutline(source: string): string;
