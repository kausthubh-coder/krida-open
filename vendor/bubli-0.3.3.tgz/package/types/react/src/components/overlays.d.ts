import { type ReactNode } from 'react';
export type DialogProps = {
    open: boolean;
    onClose: () => void;
    title: ReactNode;
    description?: ReactNode;
    children?: ReactNode;
    /** Buttons along the bottom. */
    actions?: ReactNode;
    className?: string;
};
/**
 * A modal dialog on the native element, which gives the focus trap, Esc and the
 * inert page for free. Solid and readable; grows from the middle of the screen.
 */
export declare function Dialog({ open, onClose, title, description, children, actions, className }: DialogProps): import("react").JSX.Element | null;
export type SheetProps = {
    open: boolean;
    onClose: () => void;
    title: ReactNode;
    children?: ReactNode;
    className?: string;
};
/** A panel from the bottom edge that follows the finger 1:1 and leaves with its speed. Solid, no film. */
export declare function Sheet({ open, onClose, title, children, className }: SheetProps): import("react").JSX.Element | null;
type ToastEntry = {
    id: number;
    message: ReactNode;
    action?: {
        label: string;
        onClick: () => void;
    };
};
type ToastContextValue = {
    toast: (message: ReactNode, options?: {
        action?: ToastEntry['action'];
        duration?: number;
    }) => void;
};
/** Shows a short message. */
export declare const useToast: () => ToastContextValue;
/** Put once near the root; children call useToast(). */
export declare function ToastProvider({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
export {};
