type Holder = {
    settleFast: () => void;
};
export declare function claimHover(next: Holder): void;
export declare function releaseHover(current: Holder): void;
export {};
