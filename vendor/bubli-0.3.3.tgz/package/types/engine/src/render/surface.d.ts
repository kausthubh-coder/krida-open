import type { BubbleBody } from '../physics/bubble-body';
import { type BubbleRect } from './gl-context';
import { type Material } from './material';
/**
 * A flat coloured layer drawn under the bubble, such as a switch or slider
 * track, in CSS pixels from the canvas's top left. Colours are CSS colours.
 */
export type Layer = {
    x: number;
    y: number;
    width: number;
    height: number;
    radius: number;
    /** Where the fill ends, as a fraction of the width. */
    fill: number;
    track: string;
    from: string;
    to?: string;
};
export type Surface = {
    setMaterial: (material: Material) => void;
    setLightTheme: (light: boolean) => void;
    setLayer: (layer: Layer | null) => void;
    /** Draw as this box (CSS pixels from the host's top left) instead of the host's own. */
    setShape: (shape: BubbleRect | null) => void;
    /** The host moved inside its canvas, as a thumb does. */
    measure: () => void;
    /** Ask for a draw on the next frame: the body moved. */
    wake: () => void;
    /** Overrides how solid the body is, without touching the material: for a panel filling in as it grows. */
    setBodyOpacity: (opacity: number | null) => void;
    /** The film's clock, for another bubble to carry on. */
    filmClock: () => {
        time: number;
        spark: number;
    };
    adoptFilmClock: (clock: {
        time: number;
        spark: number;
    }) => void;
    setStill: (still: boolean) => void;
    /** Hidden by its component (a lens at rest): keeps its pixels and stops drifting. */
    setDormant: (dormant: boolean) => void;
    dispose: () => void;
};
/** The colour the page has behind this element: its first non-clear ancestor backgrounds, blended. */
export declare function readPageTone(element: Element): [number, number, number];
export declare function createSurface(options: {
    canvas: HTMLCanvasElement;
    host: HTMLElement;
    body: BubbleBody;
    material: Material;
    light: boolean;
    still: boolean;
    onPainted: () => void;
    onBroken: () => void;
}): Surface | null;
