export type Box = {
    left: number;
    top: number;
    right: number;
    width: number;
    height: number;
};
/**
 * Where a host sits inside its canvas, in the canvas's own pixels, read from what the screen
 * says. A page can turn a whole frame a quarter (a video player on an upright phone), and then
 * the screen's width is the canvas's height and its left edge the canvas's top. Without this,
 * anything longer than it is tall draws outside its canvas and disappears.
 *
 * Both boxes are measured through whatever scales them, so the zoom is the host's scale over the
 * canvas's. Taken from the host alone, a dialog measured while it scales in from 95% drew its bubble
 * off centre for as long as it stayed open: nothing measures again when only a transform changes.
 */
export declare function placeInCanvas(area: Box, box: Box, canvas: {
    width: number;
    height: number;
}, host: {
    width: number;
    height: number;
}): {
    scale: number;
    zoomX: number;
    zoomY: number;
    x: number;
    y: number;
};
