export declare const bubbleEnvironments: readonly ["studio", "window", "sky", "soft"];
export type BubbleEnvironment = (typeof bubbleEnvironments)[number];
/** Lighting choices, including auto: soft light on light pages, the studio on dark ones. */
export declare const bubbleLightings: readonly ["studio", "window", "sky", "soft", "auto"];
export type BubbleLighting = (typeof bubbleLightings)[number];
/** How the window light sits: along the edge, or as the intro's bubble window. */
export declare const bubbleWindowStyles: readonly ["edge", "bubble"];
export type BubbleWindowStyle = (typeof bubbleWindowStyles)[number];
/** Shapes of the glint past the window light; auto varies it per bubble. */
export declare const bubbleGlintShapes: readonly ["auto", "dot", "dash", "pair", "none"];
export type BubbleGlintShape = (typeof bubbleGlintShapes)[number];
/** Shapes the window light's inverted twin can take. */
export declare const bubbleTwinShapes: readonly ["arc", "crescent", "streak", "dot", "mirror"];
export type BubbleTwinShape = (typeof bubbleTwinShapes)[number];
export type Material = {
    /** Corner radius in pixels at a 16 px font; it grows with the text. Large values give fully round ends. */
    radius: number;
    /** Width of the liquid glass bevel in pixels at a 16 px font; it grows with the text. */
    bevel: number;
    /** Mean film thickness in nanometres. */
    thickness: number;
    /** Strength of the oil-like interference colours; 1 is physical. */
    iridescence: number;
    /** How much gravity has drained the cap thin and the base thick. */
    drainage: number;
    /** Marangoni swirls stirring the film. */
    swirl: number;
    /** Size of the film's colour bands; larger values give broader, calmer bands. */
    filmScale: number;
    /** Opacity of the oil colours, independent of the base tint's alpha. */
    oilOpacity: number;
    /** Share of the film showing oil colours; below 1 leaves clear film between slicks. */
    oilCoverage: number;
    /**
     * On large components (longer than about 10 em), how far in from the rim
     * the oil reaches, in pixels at a 16 px font, so their middle stays clear.
     * Small controls keep oil all over. 0 shows oil everywhere.
     */
    oilEdge: number;
    /** How strongly large components clear the oil from their middle: 0 not at all, 1 fully; above 1 the rim band narrows too (2 is half as wide). */
    oilEdgeFade: number;
    /** Clear oil and reflected haze from the centre at any size: 1 leaves a transparent middle and an oily rim. */
    clearCenter: number;
    /** Base colour; also guides the soap, shades and highlights set to auto. */
    /**
     * Colour of the body; Opacity sets how solid. Auto is the page's own,
     * white on light pages and black on dark ones.
     */
    tint: string;
    /** Gentle colour filter for the multicolour film; auto and transparent leave it unchanged. */
    soapColor: string;
    /** Natural spectral colours by default, or six editable hue families. */
    soapPalette: 'natural' | 'custom';
    soapPaletteRed: string;
    soapPaletteGold: string;
    soapPaletteGreen: string;
    soapPaletteCyan: string;
    soapPaletteBlue: string;
    soapPaletteViolet: string;
    /** Colour and strength of the darker film and bottom shade; auto leaves them unchanged. */
    soapShadeColor: string;
    /** Colour and strength of reflected light, bevel and window; auto leaves them unchanged. */
    soapHighlightColor: string;
    /** Film reflectance multiplier; 1 is soapy water. */
    reflectivity: number;
    /** Reflections of the nearby page in the rim of the bubble. */
    mirage: number;
    /**
     * How much of the bubbles behind this one show through its film, which
     * the backdrop leaves out. 0 shows the backdrop alone.
     */
    seeThrough: number;
    /** How far those bubbles bend, in multiples of the backdrop's refraction. */
    seeThroughBend: number;
    /**
     * How solid the tint fills the bubble, over the tint's own alpha: 1 is an
     * opaque body, 0 none. Below 0 (the default) the tint's alpha is used.
     */
    opacity: number;
    /** The studio's bounce light from below, a pale crescent along the lower rim; 0 removes it. */
    floorLight: number;
    /** The reflection at the top drawn as a large cartoon window and spark that follow the pointer. */
    windowLight: boolean;
    /** edge follows the shape's top-left edge; bubble is the intro's bean in its rounding, as it first was. */
    windowStyle: BubbleWindowStyle;
    /** How far the window light runs; 1 as drawn. */
    windowLength: number;
    /** How far in from the edge it sits; 1 as drawn. */
    windowMargin: number;
    /** On long shapes, how closely the edge window follows the curve: 0 straight, 1 the edge. */
    windowBend: number;
    /** Thickness of the window light and its glint; 1 as drawn. */
    windowSize: number;
    /** Thickness of the window band alone; 1 as drawn. */
    windowWidth: number;
    /** How long the overhead light's highlight along a top edge fades out; 0 ends it crisply. */
    topFade: number;
    /** How that highlight's far end thins to a point (below 1) or stays blunt; 1 as drawn. */
    topTail: number;
    /** How far that highlight runs along the top edge; 1 as drawn. */
    topLength: number;
    /** How much the window fades towards its right end: 0 even, 1 out by its tip; 0.24 as drawn. */
    windowGradient: number;
    /** Thickness of the window's thick left end against the rest; 1 as drawn. */
    windowHead: number;
    /** Thickness of the window's far end: low is pointed, high is blunt; 1 as drawn. */
    windowTail: number;
    /** Shape of the glint past the window; auto varies it per bubble on the edge style. */
    glintShape: BubbleGlintShape;
    /** Size of the glint; 1 as drawn. */
    glintSize: number;
    /** Brightness of the glint; 1 as drawn. */
    glintIntensity: number;
    /** How far past the window the glint sits; 0 as drawn. */
    glintDistance: number;
    /** How far in from the edge the glint sits; 0 as drawn, negative towards the rim. */
    glintHeight: number;
    /** Brightness of the window light and its twin; 1 as drawn. */
    windowIntensity: number;
    /** The window's faint inverted twin on the far wall, at the bottom right. */
    windowTwin: boolean;
    /** Shape of that twin. */
    windowTwinShape: BubbleTwinShape;
    /** The room's key light (the window, the softbox or the sun) and its reflection. */
    keyLight: boolean;
    /** A soft band along the bottom inside: a shade on light pages, a glow on dark ones. */
    bottomShade: boolean;
    /** Colour of that band; auto follows the theme. Its opacity sets the strength. */
    bottomShadeColor: string;
    /** How far around the bubble the mirrored surroundings reach, in radii. */
    reach: number;
    /** Bends the light passing through; 0 is a true thin film. */
    refraction: number;
    /** Morphs the soap film into liquid glass: 0 is a bubble, 1 a glass lens. */
    glass: number;
    /** Colour split of light refracted by the glass. */
    dispersion: number;
    environment: BubbleEnvironment;
    /** Pointer parallax of the reflected room. */
    tilt: number;
    /** Jiggle on hover and press. */
    wobble: number;
    speed: number;
    paused: boolean;
    seed: number;
    maxDpr: number;
};
export declare const materialDefaults: Material;
/** Tuning as components accept it: lighting may still be auto. */
export type MaterialSettings = Omit<Material, 'environment'> & {
    environment: BubbleLighting;
};
export declare function normalizeMaterial(value: Partial<Material>): Material;
/** Light pages: clear centre, pale oil. */
export declare const lightGlass: Partial<Material>;
/** Dark pages: vivid oil bands, a clear bottom shade. */
export declare const rainbowGlass: Partial<Material>;
export declare const frostedLight: Partial<Material>;
export declare const frostedDark: Partial<Material>;
export declare const barLight: Partial<Material>;
export declare const barDark: Partial<Material>;
/**
 * What bars and panels are made of. bubble is the default: the small controls' film
 * on a big shape, a bit frosted so what's written on it reads. liquid is Apple's clear
 * glass. soap keeps that body with the film on its edge. solid is for reading apps.
 */
export type Surface = 'bubble' | 'liquid' | 'soap' | 'solid';
export declare const surfaces: readonly Surface[];
export declare const defaultSurface: Surface;
export declare function surfaceMaterial(surface: Surface, look: 'frosted' | 'bar', theme: Theme): Partial<Material>;
/** Whether a Firefox that may not draw the blur needs a thicker body to stay readable. */
export declare const surfaceBlurs: (surface: Surface) => surface is "liquid" | "soap";
/** Small controls can wear the same glass instead of the film, if an app wants. */
export declare const liquidControlLight: Partial<Material>;
export declare const liquidControlDark: Partial<Material>;
export type Theme = 'light' | 'dark';
export declare const glassFor: (theme: Theme) => Partial<Material>;
export declare const frostedFor: (theme: Theme) => Partial<Material>;
export declare const liquidControlFor: (theme: Theme) => Partial<Material>;
