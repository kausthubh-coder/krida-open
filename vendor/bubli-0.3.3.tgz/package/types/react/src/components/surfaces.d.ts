import { type AnchorHTMLAttributes, type ButtonHTMLAttributes, type HTMLAttributes, type ReactNode } from 'react';
export type CardProps = HTMLAttributes<HTMLDivElement> & {
    /** Hover and press shade, for a card that's a link or button inside. */
    interactive?: boolean;
};
/** A plain card. No glass and no rainbow: it holds content, it isn't a control. */
export declare function Card({ interactive, className, ...rest }: CardProps): import("react").JSX.Element;
export type ListRowProps = {
    leading?: ReactNode;
    title: ReactNode;
    subtitle?: ReactNode;
    trailing?: ReactNode;
    selected?: boolean;
    className?: string;
} & (({
    href: string;
} & AnchorHTMLAttributes<HTMLAnchorElement>) | ({
    href?: undefined;
} & ButtonHTMLAttributes<HTMLButtonElement>));
/** A row in a list. It gets a plain shade on hover, and the shade leaves at once. */
export declare function ListRow({ leading, title, subtitle, trailing, selected, className, ...rest }: ListRowProps): import("react").JSX.Element;
export type ChipProps = ButtonHTMLAttributes<HTMLButtonElement> & {
    selected?: boolean;
    defaultSelected?: boolean;
    onSelectedChange?: (selected: boolean) => void;
    icon?: ReactNode;
};
/** A small toggleable filter. A bubble, since it's a small control. */
export declare function Chip({ selected, defaultSelected, onSelectedChange, icon, className, children, onClick, ...rest }: ChipProps): import("react").JSX.Element;
export type StepperProps = {
    value?: number;
    defaultValue?: number;
    min?: number;
    max?: number;
    step?: number;
    onValueChange?: (value: number) => void;
    /** What's being counted, for screen readers. */
    label: string;
    className?: string;
};
/** A number with a minus and a plus. The buttons are bubbles; the body between them is plain. */
export declare function Stepper({ value, defaultValue, min, max, step, onValueChange, label, className, }: StepperProps): import("react").JSX.Element;
export type ProgressProps = {
    /** 0 to 1. Left out, it runs without saying how far. */
    value?: number;
    label: string;
    className?: string;
};
/** A plain progress bar: it should sit quietly, so no glass. */
export declare function Progress({ value, label, className }: ProgressProps): import("react").JSX.Element;
