import { type SpringConfig } from './spring';
/**
 * Every number that decides how a bubble moves. Kicks are velocities in radii
 * per second at the system wobble of 0.4; a material's wobble scales them.
 */
export type BodyPreset = {
    /** l=2 (oval) and l=3 (pear) shape modes. */
    mode2: SpringConfig;
    mode3: SpringConfig;
    mode2Limit: number;
    mode3Limit: number;
    /** Vertical press squash: uSquash = (1 + 0.7 s, 1 - s). */
    squash: SpringConfig;
    squashPressed: number;
    /** Stretch along the travel direction, as an l=2 term. */
    stretch: SpringConfig;
    stretchMax: number;
    /** Speed in radii per second where stretch reaches about 3/4 of its maximum. */
    stretchSpeed: number;
    /** Uniform swell of the drawn size. */
    swell: SpringConfig;
    swellPressed: number;
    /** Resized box: its size springs to the new one and rings the modes a little. */
    size: SpringConfig;
    resizeKick: number;
    resizeKickMax: number;
    /** Takes a new size at once: what's inside a panel has already moved, and would stand outside a rim still on its way. */
    exactSize?: boolean;
    /** Room reflections following the pointer. */
    tilt: SpringConfig;
    enterKick: number;
    leaveKick: number;
    releaseKick: number;
    reboundKick: number;
    /** A key pressed inside it, in radii per second. */
    typeKick: number;
};
export declare const bodyPresets: {
    /** Buttons, chips: wobble on hover, squash and swell on press. */
    control: {
        squashPressed: number;
        swellPressed: number;
        enterKick: number;
        leaveKick: number;
        releaseKick: number;
        reboundKick: number;
        typeKick: number;
        mode2: SpringConfig;
        mode3: SpringConfig;
        mode2Limit: number;
        mode3Limit: number;
        squash: SpringConfig;
        stretch: SpringConfig;
        swell: SpringConfig;
        size: SpringConfig;
        tilt: SpringConfig;
        stretchMax: number;
        stretchSpeed: number;
        resizeKick: number;
        resizeKickMax: number;
    };
    /** Slider and toggle thumbs: the swell is set by the component. */
    thumb: {
        squashPressed: number;
        swellPressed: number;
        enterKick: number;
        leaveKick: number;
        releaseKick: number;
        reboundKick: number;
        typeKick: number;
        mode2: SpringConfig;
        mode3: SpringConfig;
        mode2Limit: number;
        mode3Limit: number;
        squash: SpringConfig;
        stretch: SpringConfig;
        swell: SpringConfig;
        size: SpringConfig;
        tilt: SpringConfig;
        stretchMax: number;
        stretchSpeed: number;
        resizeKick: number;
        resizeKickMax: number;
    };
    /** Sliding lenses in tab bars and segmented controls: stretch, no hover wobble. */
    lens: {
        swell: SpringConfig;
        mode2Limit: number;
        mode3Limit: number;
        stretchMax: number;
        stretchSpeed: number;
        squashPressed: number;
        swellPressed: number;
        enterKick: number;
        leaveKick: number;
        releaseKick: number;
        reboundKick: number;
        typeKick: number;
        mode2: SpringConfig;
        mode3: SpringConfig;
        squash: SpringConfig;
        stretch: SpringConfig;
        size: SpringConfig;
        tilt: SpringConfig;
        resizeKick: number;
        resizeKickMax: number;
    };
    /** Menus and panels: never wobble under the pointer, only when they resize. */
    panel: {
        exactSize: true;
        mode2: SpringConfig;
        mode3: SpringConfig;
        mode2Limit: number;
        mode3Limit: number;
        squashPressed: number;
        swellPressed: number;
        enterKick: number;
        leaveKick: number;
        releaseKick: number;
        reboundKick: number;
        typeKick: number;
        squash: SpringConfig;
        stretch: SpringConfig;
        swell: SpringConfig;
        size: SpringConfig;
        tilt: SpringConfig;
        stretchMax: number;
        stretchSpeed: number;
        resizeKick: number;
        resizeKickMax: number;
    };
    /**
     * A panel that's a bubble: a menu is its button grown bigger, so it rings on arrival
     * and gives a little to the pointer, more gently than a button because it's bigger.
     */
    bubblePanel: {
        exactSize: true;
        mode2: SpringConfig;
        mode3: SpringConfig;
        mode2Limit: number;
        mode3Limit: number;
        squashPressed: number;
        swellPressed: number;
        enterKick: number;
        leaveKick: number;
        releaseKick: number;
        reboundKick: number;
        typeKick: number;
        squash: SpringConfig;
        stretch: SpringConfig;
        swell: SpringConfig;
        size: SpringConfig;
        tilt: SpringConfig;
        stretchMax: number;
        stretchSpeed: number;
        resizeKick: number;
        resizeKickMax: number;
    };
    /** A bar that's a bubble: it never changes size, and gives a little to the pointer. */
    bubbleBar: {
        mode2: SpringConfig;
        mode3: SpringConfig;
        mode2Limit: number;
        mode3Limit: number;
        squashPressed: number;
        swellPressed: number;
        enterKick: number;
        leaveKick: number;
        releaseKick: number;
        reboundKick: number;
        typeKick: number;
        squash: SpringConfig;
        stretch: SpringConfig;
        swell: SpringConfig;
        size: SpringConfig;
        tilt: SpringConfig;
        stretchMax: number;
        stretchSpeed: number;
        resizeKick: number;
        resizeKickMax: number;
    };
    /** Floating bars: the bar never changes size. Reflections follow the pointer. */
    bar: {
        mode2: SpringConfig;
        mode3: SpringConfig;
        mode2Limit: number;
        mode3Limit: number;
        squashPressed: number;
        swellPressed: number;
        enterKick: number;
        leaveKick: number;
        releaseKick: number;
        reboundKick: number;
        typeKick: number;
        squash: SpringConfig;
        stretch: SpringConfig;
        swell: SpringConfig;
        size: SpringConfig;
        tilt: SpringConfig;
        stretchMax: number;
        stretchSpeed: number;
        resizeKick: number;
        resizeKickMax: number;
    };
    /** Fields move just as buttons do, and a key gives a small wobble. */
    field: {
        squashPressed: number;
        swellPressed: number;
        enterKick: number;
        leaveKick: number;
        releaseKick: number;
        reboundKick: number;
        typeKick: number;
        mode2: SpringConfig;
        mode3: SpringConfig;
        mode2Limit: number;
        mode3Limit: number;
        squash: SpringConfig;
        stretch: SpringConfig;
        swell: SpringConfig;
        size: SpringConfig;
        tilt: SpringConfig;
        stretchMax: number;
        stretchSpeed: number;
        resizeKick: number;
        resizeKickMax: number;
    };
};
export type BodyPresetName = keyof typeof bodyPresets;
/** Springs for things components move: lenses, menus, thumbs, sheets. */
export declare const motionSprings: {
    /** About 3% overshoot, landing in about 450 ms: fast but you see it grow. */
    menuOpen: {
        stiffness: number;
        damping: number;
    };
    /** Critically damped: closing never bounces. */
    menuClose: {
        stiffness: number;
        damping: number;
    };
    /** Tab and segmented lens. */
    lens: {
        stiffness: number;
        damping: number;
    };
    toggle: {
        stiffness: number;
        damping: number;
    };
    sheet: {
        stiffness: number;
        damping: number;
    };
    /** Search growing into its field. */
    morph: {
        stiffness: number;
        damping: number;
    };
    toast: {
        stiffness: number;
        damping: number;
    };
};
