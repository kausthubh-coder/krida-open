import { type Material } from '../../engine/src/index';
import { type ButtonHTMLAttributes, type Ref } from 'react';
export type ToggleProps = Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'onChange' | 'value'> & {
    ref?: Ref<HTMLButtonElement>;
    checked?: boolean;
    defaultChecked?: boolean;
    onCheckedChange?: (checked: boolean) => void;
    /** Track colour when on. */
    color?: string;
    /** 1 is a 64 x 28 px track. */
    scale?: number;
    material?: Partial<Material>;
};
/** A switch whose thumb is a lens over its track. It swells while pressed or moving, and slides on a spring. */
export declare function Toggle({ ref, checked, defaultChecked, onCheckedChange, color, scale, material, className, style, onClick, onPointerDown, disabled, ...rest }: ToggleProps): import("react").JSX.Element;
