/** Straight RGBA in 0-1 for any CSS colour. */
export declare function cssColour(value: string): [number, number, number, number];
/** A colour's hue at full strength, kept even when it is transparent. */
export declare function cssHue(value: string): [number, number, number];
