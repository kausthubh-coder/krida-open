import { type BendVariant, type BodyPresetName, type Bubble, type Material, type Surface } from '../../engine/src/index';
import { type ComponentPropsWithoutRef, type ElementType, type ReactNode, type Ref } from 'react';
import { type BubbleFamily } from '../provider';
import { type BubbleLook } from '../use-bubble';
export type GlassProps<T extends ElementType> = {
    as?: T;
    ref?: Ref<HTMLElement>;
    /** How it moves. */
    preset?: BodyPresetName;
    /** glass for small controls, frosted for panels that cover content. */
    look?: BubbleLook;
    material?: Partial<Material>;
    /**
     * Bend what's behind it. Left out, a control bends when it floats over content
     * (inside AboveScene). In a page's flow it sits on a flat surface, where a bend
     * costs GPU and shows nothing.
     */
    bend?: boolean;
    /** Regular blurs what's behind so a label stays readable. Clear is a pure lens. */
    variant?: BendVariant;
    /** How far the bend may reach, in pixels. */
    bendMax?: number;
    /** What a bar or panel is made of, over the theme's. */
    surface?: Surface;
    /** Which of the theme's tune applies. Left out, it follows the look. */
    family?: BubbleFamily;
    /** Gets the bubble once it exists, to drive it directly. */
    onBubble?: (bubble: Bubble) => void;
    name: string;
    children?: ReactNode;
} & Omit<ComponentPropsWithoutRef<T>, 'as' | 'name'>;
/**
 * A box drawn as a bubble. Its layout box is its hit area and never moves; the
 * canvas and bend sit in extra elements that take no pointer events, so whatever
 * the bubble does, the thing you aim at stays put.
 */
export declare function Glass<T extends ElementType = 'div'>({ as, ref, preset, look, material, bend, variant, bendMax, surface, family, onBubble, name, className, children, ...rest }: GlassProps<T>): import("react").JSX.Element;
